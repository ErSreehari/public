package com.kotak.flashpay.paymentcenter.model;

public class Constants {

    public static final String VALIDATION_TASK_QUEUE_NAME = "validation_task_queue";
    public static final String PAYMENT_PROCESSOR_TASK_QUEUE_NAME = "payment_processor_task_queue";
    public static final String PAYMENT_CENTER_TASK_QUEUE_NAME = "payment_center_task_queue";
    public static final String LIMIT_CHECK_TASK_QUEUE_NAME = "limit_check_task_queue";
    public static final String IMPS_PAYMENT_PROCESSOR_TASK_QUEUE_NAME = "imps_payment_processor_task_queue";
}