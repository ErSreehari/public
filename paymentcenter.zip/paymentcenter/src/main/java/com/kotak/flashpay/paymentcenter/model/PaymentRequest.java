package com.kotak.flashpay.paymentcenter.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class PaymentRequest {
    private String amount;
    private String currency;
    private String comments;
    private String paymentType;
    private String toAccount;
    private String fromAccount;
    private Instant paymentDateTime;
}
