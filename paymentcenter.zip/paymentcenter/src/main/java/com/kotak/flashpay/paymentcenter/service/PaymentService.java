package com.kotak.flashpay.paymentcenter.service;

import com.kotak.flashpay.paymentcenter.entity.Payment;
import com.kotak.flashpay.paymentcenter.model.PaymentRequest;

public interface PaymentService {

    Payment savePayment(Payment data);
}
