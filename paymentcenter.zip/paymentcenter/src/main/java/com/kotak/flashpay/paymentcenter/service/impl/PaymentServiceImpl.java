package com.kotak.flashpay.paymentcenter.service.impl;

import com.kotak.flashpay.paymentcenter.entity.Payment;
import com.kotak.flashpay.paymentcenter.model.PaymentRequest;
import com.kotak.flashpay.paymentcenter.repository.PaymentsRepo;
import com.kotak.flashpay.paymentcenter.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    PaymentsRepo paymentsRepo;

    @Override
    public Payment savePayment(Payment payment) {
        return paymentsRepo.save(payment);
    }
}
