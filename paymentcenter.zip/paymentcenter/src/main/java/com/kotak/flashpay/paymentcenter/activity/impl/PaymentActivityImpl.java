package com.kotak.flashpay.paymentcenter.activity.impl;

import com.kotak.flashpay.paymentcenter.activity.PaymentActivity;
import com.kotak.flashpay.paymentcenter.entity.Payment;
import com.kotak.flashpay.paymentcenter.repository.PaymentsRepo;
import io.temporal.spring.boot.ActivityImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.kotak.flashpay.paymentcenter.model.Constants.PAYMENT_CENTER_TASK_QUEUE_NAME;

@Component
@ActivityImpl(taskQueues = PAYMENT_CENTER_TASK_QUEUE_NAME)
public class PaymentActivityImpl implements PaymentActivity {

    @Autowired
    PaymentsRepo paymentsRepo;

    @Override
    public String save(Payment payment) {
        paymentsRepo.save(payment);
        return "SAVED";
    }

    @Override
    public String updateStatus(String transactionID, String status) {
        paymentsRepo.findById(transactionID).ifPresent(payment -> {
            payment.setStatus(status);
            paymentsRepo.save(payment);
        });
        return "UPDATED";
    }
}
