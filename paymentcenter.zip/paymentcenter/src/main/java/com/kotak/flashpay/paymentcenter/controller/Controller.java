package com.kotak.flashpay.paymentcenter.controller;

import com.kotak.flashpay.paymentcenter.entity.Payment;
import com.kotak.flashpay.paymentcenter.model.Constants;
import com.kotak.flashpay.paymentcenter.model.Message;
import com.kotak.flashpay.paymentcenter.model.PaymentRequest;
import com.kotak.flashpay.paymentcenter.service.PaymentService;
import com.kotak.flashpay.paymentcenter.workflow.PaymentProcessorWorkflow;
import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowOptions;
import io.temporal.client.WorkflowStub;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@Log4j2
@RestController
public class Controller {

    @Autowired
    WorkflowClient client;

    @Autowired
    PaymentService paymentService;

    @PostMapping(value = "/pay", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message startSubscription(@RequestBody PaymentRequest data) {

        Payment payment = paymentService.savePayment(new Payment(data));

        WorkflowOptions options = WorkflowOptions.newBuilder()
                .setWorkflowId(payment.getTransactionId())
                .setTaskQueue(Constants.PAYMENT_PROCESSOR_TASK_QUEUE_NAME)
                .build();
        PaymentProcessorWorkflow workflow = client.newWorkflowStub(PaymentProcessorWorkflow.class, options);
        WorkflowClient.start(workflow::doPayment,payment);

        payment.setStatus("INITIATED");
        paymentService.savePayment(payment);

        return new Message("Resource created successfully with transaction id: " + payment.getTransactionId());
    }

    @GetMapping(value = "/getInternalStatus", produces = MediaType.APPLICATION_JSON_VALUE)
    public String getQuery(@RequestParam String email) {

        PaymentProcessorWorkflow workflow = client.newWorkflowStub(PaymentProcessorWorkflow.class, email);
        return workflow.details();
    }

//    @DeleteMapping(value = "/cancel", produces = MediaType.APPLICATION_JSON_VALUE)
//    public Message endSubscription(@RequestBody PaymentRequest data) {
//
//        PaymentProcessorWorkflow workflow = client.newWorkflowStub(PaymentProcessorWorkflow.class, data.getTransactionId());
//        WorkflowStub workflowStub = WorkflowStub.fromTyped(workflow);
//        workflowStub.cancel();
//
//        return new Message("Requesting cancellation of payment with transaction id: " + data.getTransactionId());
//    }
}