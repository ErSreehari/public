package com.kotak.flashpay.paymentcenter.entity;

import com.kotak.flashpay.paymentcenter.model.PaymentRequest;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "payments")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String transactionId;
    private String amount;
    private String currency;
    private String comments;
    private String paymentType;
    private String toAccount;
    private String fromAccount;
    private Instant paymentDateTime;
    private String status;

    public Payment(PaymentRequest paymentRequest) {
        this.amount = paymentRequest.getAmount();
        this.currency = paymentRequest.getCurrency();
        this.comments = paymentRequest.getComments();
        this.paymentType = paymentRequest.getPaymentType();
        this.toAccount = paymentRequest.getToAccount();
        this.fromAccount = paymentRequest.getFromAccount();
        this.paymentDateTime = paymentRequest.getPaymentDateTime();
        this.status="ACCEPTED";
    }
}
