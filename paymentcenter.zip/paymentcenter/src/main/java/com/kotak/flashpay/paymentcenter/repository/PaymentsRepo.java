package com.kotak.flashpay.paymentcenter.repository;

import com.kotak.flashpay.paymentcenter.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository is an interface that provides access to data in a database
 */
public interface PaymentsRepo extends JpaRepository<Payment, String> {
}