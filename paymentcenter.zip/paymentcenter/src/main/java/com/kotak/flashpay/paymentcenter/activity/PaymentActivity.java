package com.kotak.flashpay.paymentcenter.activity;

import com.kotak.flashpay.paymentcenter.entity.Payment;
import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface PaymentActivity {
  public String save(Payment person);
  public String updateStatus(String transactionID, String status);

}