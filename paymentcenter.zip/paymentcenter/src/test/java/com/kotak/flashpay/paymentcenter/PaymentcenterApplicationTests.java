package com.kotak.flashpay.paymentcenter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class PaymentcenterApplicationTests {

	@Test
	void contextLoads() {
		System.out.println(Runtime.getRuntime().availableProcessors());
	}

}
