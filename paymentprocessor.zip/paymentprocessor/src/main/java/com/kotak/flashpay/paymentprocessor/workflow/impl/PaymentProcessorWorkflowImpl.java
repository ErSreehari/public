package com.kotak.flashpay.paymentprocessor.workflow.impl;

import com.kotak.flashpay.paymentprocessor.activity.PaymentActivity;
import com.kotak.flashpay.paymentprocessor.model.Payment;
import com.kotak.flashpay.paymentprocessor.workflow.ImpsPaymentProcessorWorkflow;
import com.kotak.flashpay.paymentprocessor.workflow.LimitCheckWorkflow;
import com.kotak.flashpay.paymentprocessor.workflow.PaymentProcessorWorkflow;
import com.kotak.flashpay.paymentprocessor.workflow.ValidationPaymentRequestWorkflow;
import io.temporal.activity.ActivityOptions;
import io.temporal.common.RetryOptions;
import io.temporal.spring.boot.WorkflowImpl;
import io.temporal.workflow.Async;
import io.temporal.workflow.ChildWorkflowOptions;
import io.temporal.workflow.Promise;
import io.temporal.workflow.Workflow;

import java.time.Duration;

import static com.kotak.flashpay.paymentprocessor.model.Constants.*;

@WorkflowImpl(workers = "payment-processor-task-worker")
public class PaymentProcessorWorkflowImpl implements PaymentProcessorWorkflow {

    String state = "PENDING";

    @Override
    public void doPayment(Payment data) {
        updateStatus("VALIDATION");
        Promise<String> validationResult = Async.function(getValidationPaymentRequestWorkflow()::doValidation, data);
        if (validationResult.get().equalsIgnoreCase("SUCCESS")) {
            updateStatus("LIMIT CHECK");
            Promise<String> limitCheckResult = Async.function(getLimitCheckWorkflow()::checkLimit, data);
            if (limitCheckResult.get().equalsIgnoreCase("SUCCESS")) {
                updateStatus("IMPS PAYMENT INITIATED");
                Promise<String> impsPaymentResult = Async.function(getImpsPaymentProcessorWorkflow()::doImpsPayment, data);
                if (impsPaymentResult.get().equalsIgnoreCase("SUCCESS")) {
                    updateStatus("PAYMENT SUCCESS");
                } else {
                    updateStatus("FAILED IMPS PAYMENT");
                }
            } else {
                updateStatus("FAILED LIMIT CHECK");
            }
        } else {
            updateStatus("FAILED VALIDATION");
        }
    }

    private void updateStatus(String status) {
        PaymentActivity activity =
                Workflow.newActivityStub(
                        PaymentActivity.class,
                        ActivityOptions.newBuilder()
                                .setStartToCloseTimeout(Duration.ofSeconds(2))
                                .setTaskQueue(PAYMENT_CENTER_TASK_QUEUE_NAME)
                                .build());
        activity.updateStatus(Workflow.getInfo().getWorkflowId(), status);
        this.state = status;
    }

    @Override
    public String details() {
        return this.state;
    }

    private static ImpsPaymentProcessorWorkflow getImpsPaymentProcessorWorkflow() {
        ChildWorkflowOptions options = ChildWorkflowOptions.newBuilder()
                .setTaskQueue(IMPS_PAYMENT_PROCESSOR_TASK_QUEUE_NAME)
                .setRetryOptions(RetryOptions.newBuilder()
                        .setBackoffCoefficient(2)
                        .build())
                .build();
        return Workflow.newChildWorkflowStub(ImpsPaymentProcessorWorkflow.class, options);
    }

    private static LimitCheckWorkflow getLimitCheckWorkflow() {
        ChildWorkflowOptions options = ChildWorkflowOptions.newBuilder()
                .setTaskQueue(LIMIT_CHECK_TASK_QUEUE_NAME)
                .build();
        return Workflow.newChildWorkflowStub(LimitCheckWorkflow.class, options);
    }

    private static ValidationPaymentRequestWorkflow getValidationPaymentRequestWorkflow() {
        ChildWorkflowOptions options = ChildWorkflowOptions.newBuilder()
                .setTaskQueue(VALIDATION_TASK_QUEUE_NAME)
                .build();
        return Workflow.newChildWorkflowStub(ValidationPaymentRequestWorkflow.class, options);
    }
}
