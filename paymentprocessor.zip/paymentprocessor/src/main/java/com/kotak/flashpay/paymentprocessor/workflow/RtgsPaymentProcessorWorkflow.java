package com.kotak.flashpay.paymentprocessor.workflow;

import com.kotak.flashpay.paymentprocessor.model.Payment;
import io.temporal.workflow.QueryMethod;
import io.temporal.workflow.WorkflowInterface;
import io.temporal.workflow.WorkflowMethod;

@WorkflowInterface
public interface RtgsPaymentProcessorWorkflow {

    @WorkflowMethod
    public void doRtgsPayment(Payment data);

    @QueryMethod
    public String details();

}