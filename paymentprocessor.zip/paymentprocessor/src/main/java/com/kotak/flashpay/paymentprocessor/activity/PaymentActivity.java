package com.kotak.flashpay.paymentprocessor.activity;

import com.kotak.flashpay.paymentprocessor.model.Payment;
import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface PaymentActivity {
  public String save(Payment person);
  public String updateStatus(String transactionID, String status);

}