package com.kotak.flashpay.impspaymentprocessor.workflow.impl;

import com.kotak.flashpay.impspaymentprocessor.activity.ImpsPaymentActivity;
import com.kotak.flashpay.impspaymentprocessor.model.Payment;
import com.kotak.flashpay.impspaymentprocessor.workflow.ImpsPaymentProcessorWorkflow;
import io.temporal.activity.ActivityOptions;
import io.temporal.spring.boot.WorkflowImpl;
import io.temporal.workflow.Workflow;

import java.time.Duration;

import static com.kotak.flashpay.impspaymentprocessor.model.Constants.IMPS_TASK_QUEUE_NAME;

@WorkflowImpl(workers = "imps-payment-processor-worker")
public class ImpsPaymentProcessorWorkflowImpl implements ImpsPaymentProcessorWorkflow {

        String state = "PENDING";

        @Override
        public String doImpsPayment(Payment data) {
//                throw new RuntimeException("unknown error");
                doPayment(data);
                Workflow.sleep(2000);
                this.state = "IMPS PAYMENT SUCCESSFUL";
                return "SUCCESS";
        }

        @Override
        public String details() {
                return this.state;
        }

        public boolean doPayment(Payment data) {
                ImpsPaymentActivity activity =
                        Workflow.newActivityStub(
                                ImpsPaymentActivity.class,
                                ActivityOptions.newBuilder()
                                        .setStartToCloseTimeout(Duration.ofSeconds(2))
                                        .setTaskQueue(IMPS_TASK_QUEUE_NAME)
                                        .build());
                return activity.doPayment(data);
        }
}
