package com.kotak.flashpay.impspaymentprocessor.activity.impl;

import com.kotak.flashpay.impspaymentprocessor.activity.ImpsPaymentActivity;
import com.kotak.flashpay.impspaymentprocessor.model.Payment;
import io.temporal.spring.boot.ActivityImpl;
import org.springframework.stereotype.Component;

import static com.kotak.flashpay.impspaymentprocessor.model.Constants.IMPS_TASK_QUEUE_NAME;

@Component
@ActivityImpl(taskQueues = IMPS_TASK_QUEUE_NAME)
public class ImpsPaymentActivityImpl implements ImpsPaymentActivity {

    @Override
    public boolean doPayment(Payment data) {
        //do Api calls to get the payment processed by the 3rd party.
        return !data.getAmount().isBlank();
    }
}
