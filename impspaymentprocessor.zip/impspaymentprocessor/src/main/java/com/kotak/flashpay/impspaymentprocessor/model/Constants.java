package com.kotak.flashpay.impspaymentprocessor.model;

public class Constants {

    public static final String IMPS_TASK_QUEUE_NAME = "imps_payment_processor_task_queue";
}