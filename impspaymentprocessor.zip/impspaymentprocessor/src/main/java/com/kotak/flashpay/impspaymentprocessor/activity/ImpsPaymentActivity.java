package com.kotak.flashpay.impspaymentprocessor.activity;


import com.kotak.flashpay.impspaymentprocessor.model.Payment;
import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface ImpsPaymentActivity {

    public boolean doPayment(Payment data);
}
