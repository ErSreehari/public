package com.kotak.flashpay.impspaymentprocessor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImpsPaymentProcessorApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
