package com.kotak.flashpay.limitcheck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LimitCheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
