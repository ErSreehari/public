package com.kotak.flashpay.limitcheck.model;

public class Constants {

    public static final String LIMIT_CHECK_TASK_QUEUE_NAME = "limit_check_task_queue";
}