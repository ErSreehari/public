package com.kotak.flashpay.limitcheck.activity;


import com.kotak.flashpay.limitcheck.model.Payment;
import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface LimitCheckActivity {

    public boolean checkLimit(Payment data);

}
