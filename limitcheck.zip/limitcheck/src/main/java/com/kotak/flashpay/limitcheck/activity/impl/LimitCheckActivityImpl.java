package com.kotak.flashpay.limitcheck.activity.impl;

import com.kotak.flashpay.limitcheck.activity.LimitCheckActivity;
import com.kotak.flashpay.limitcheck.model.Payment;
import io.temporal.spring.boot.ActivityImpl;
import org.springframework.stereotype.Component;

import static com.kotak.flashpay.limitcheck.model.Constants.LIMIT_CHECK_TASK_QUEUE_NAME;

@Component
@ActivityImpl(taskQueues = LIMIT_CHECK_TASK_QUEUE_NAME)
public class LimitCheckActivityImpl implements LimitCheckActivity {

    @Override
    public boolean checkLimit(Payment data) {
        //do redis calls to check for limit.
        return !data.getAmount().isBlank();
    }
}
