package com.kotak.flashpay.limitcheck.workflow.impl;

import com.kotak.flashpay.limitcheck.activity.LimitCheckActivity;
import com.kotak.flashpay.limitcheck.model.Payment;
import com.kotak.flashpay.limitcheck.workflow.LimitCheckWorkflow;
import io.temporal.activity.ActivityOptions;
import io.temporal.spring.boot.WorkflowImpl;
import io.temporal.workflow.Workflow;

import java.time.Duration;

import static com.kotak.flashpay.limitcheck.model.Constants.LIMIT_CHECK_TASK_QUEUE_NAME;

@WorkflowImpl(workers = "limit-check-task-worker")
public class LimitCheckWorkflowImpl implements LimitCheckWorkflow {

        String state = "PENDING";

        @Override
        public String checkLimit(Payment data) {
            if (isAmountInLimit(data)) {
                Workflow.sleep(2000);
                this.state = "SUCCESS";
            } else {
                this.state = "FAILED";
            }
            return this.state;
        }

        @Override
        public String details() {
            return this.state;
        }

    public boolean isAmountInLimit(Payment data) {
        LimitCheckActivity activity =
                Workflow.newActivityStub(
                        LimitCheckActivity.class,
                        ActivityOptions.newBuilder()
                                .setStartToCloseTimeout(Duration.ofSeconds(2))
                                .setTaskQueue(LIMIT_CHECK_TASK_QUEUE_NAME)
                                .build());
        return activity.checkLimit(data);
    }

}
