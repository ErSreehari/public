package com.kotak.flashpay.validation.activity;

import com.kotak.flashpay.validation.model.Payment;
import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface ValidationActivity {

    public boolean validate(Payment data);
}
