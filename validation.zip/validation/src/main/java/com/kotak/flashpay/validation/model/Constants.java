package com.kotak.flashpay.validation.model;

public class Constants {

    public static final String TASK_QUEUE_NAME = "validation_task_queue";
    public static final String VALIDATION_TASK_QUEUE_NAME = "validation_task_queue";

}