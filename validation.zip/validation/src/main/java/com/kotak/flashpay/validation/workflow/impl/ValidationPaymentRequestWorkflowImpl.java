package com.kotak.flashpay.validation.workflow.impl;

import com.kotak.flashpay.validation.activity.ValidationActivity;
import com.kotak.flashpay.validation.model.Payment;
import com.kotak.flashpay.validation.workflow.ValidationPaymentRequestWorkflow;
import io.temporal.activity.ActivityOptions;
import io.temporal.spring.boot.WorkflowImpl;
import io.temporal.workflow.Workflow;

import java.time.Duration;

import static com.kotak.flashpay.validation.model.Constants.VALIDATION_TASK_QUEUE_NAME;

@WorkflowImpl(workers = "validation-task-worker")
public class ValidationPaymentRequestWorkflowImpl implements ValidationPaymentRequestWorkflow {

    String state = "PENDING";

    @Override
    public String doValidation(Payment data) {
        if (isAmountValid(data)) {
            Workflow.sleep(2000);
            this.state = "SUCCESS";
        } else {
            this.state = "FAILED";
        }
        return this.state;
    }

    @Override
    public String details() {
        return this.state;
    }

    public boolean isAmountValid(Payment data) {
        ValidationActivity activity =
                Workflow.newActivityStub(
                        ValidationActivity.class,
                        ActivityOptions.newBuilder()
                                .setStartToCloseTimeout(Duration.ofSeconds(2))
                                .setTaskQueue(VALIDATION_TASK_QUEUE_NAME)
                                .build());
        return activity.validate(data);
    }
}
