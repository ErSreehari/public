package com.kotak.flashpay.validation.workflow;

import com.kotak.flashpay.validation.model.Payment;
import io.temporal.workflow.QueryMethod;
import io.temporal.workflow.WorkflowInterface;
import io.temporal.workflow.WorkflowMethod;

@WorkflowInterface
public interface ValidationPaymentRequestWorkflow {

    @WorkflowMethod
    public String doValidation(Payment data);

    @QueryMethod
    public String details();

}