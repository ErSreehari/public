package com.kotak.flashpay.validation.activity.impl;

import com.kotak.flashpay.validation.activity.ValidationActivity;
import com.kotak.flashpay.validation.model.Payment;
import io.temporal.spring.boot.ActivityImpl;
import org.springframework.stereotype.Component;

import static com.kotak.flashpay.validation.model.Constants.VALIDATION_TASK_QUEUE_NAME;

@Component
@ActivityImpl(taskQueues = VALIDATION_TASK_QUEUE_NAME)
public class ValidationActivityImpl implements ValidationActivity {

    @Override
    public boolean validate(Payment data) {
        //do db calls to check for configurations.
        return !data.getAmount().isBlank();
    }
}
