package com.kotak.flashpay.validation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
